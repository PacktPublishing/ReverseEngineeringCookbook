#include <Windows.h>
#include <stdio.h>
int main(){
	WCHAR  *str = L"Hello world";
	printf("%ls\n",str);
}