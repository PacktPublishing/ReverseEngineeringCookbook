#include <stdio.h>
int main(){
	char  *str = "Hello world";
	printf("%s\n",str);
}